<div class="flash-data" data-flashdata="<?= $this->session->flashdata('msg') ?>"></div>

<div class="row">
    <div class="col-md-6">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">Edit Admin</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">

                <?php
                echo validation_errors('<div class="alert alert-warning"><i class="fa fa-warning"></i> ', '</div>');
                ?>

                <form action="<?= base_url('admin/admin/edit/' . $admin->id_admin) ?>" method="post">

                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-3">
                                <label for="" class="pull-right">Nama</label>
                            </div>
                            <div class="col-md-9">
                                <input value="<?= $admin->nama_admin ?>" type="text" name="nama_admin" class="form-control">
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-3">
                                <label for="" class="pull-right">Username</label>
                            </div>
                            <div class="col-md-9">
                                <input type="text" value="<?= $admin->username_admin ?>" name="username_admin" class="form-control">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-3">
                                <label for="" class="pull-right">Email</label>
                            </div>
                            <div class="col-md-9">
                                <input type="text" value="<?= $admin->email ?>" name="email" class="form-control">
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-3">
                                <label for="" class="pull-right">Role</label>
                            </div>
                            <div class="col-md-9">
                                <select name="role" class="form-control">
                                    <option value="none">--Role--</option>
                                    <option value="Admin" <?php if ($admin->role == "Admin") {
                                                                echo "selected";
                                                            } ?>>Admin</option>
                                    <option value="Super Admin" <?php if ($admin->role == "Super Admin") {
                                                                    echo "selected";
                                                                } ?>>Super Admin</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-3">
                                <label for="" class="pull-right">Status</label>
                            </div>
                            <div class="col-md-9">
                                <select name="is_aktif" class="form-control">
                                    <option value="none">--Status--</option>
                                    <option value="0" <?php if ($admin->is_active == "0") {
                                                            echo "selected";
                                                        } ?>>Tidak Aktif</option>
                                    <option value="1" <?php if ($admin->is_active == "1") {
                                                            echo "selected";
                                                        } ?>>Aktif</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-3">
                                <label for="" class="pull-right">Password</label>
                            </div>
                            <div class="col-md-9">
                                <input type="password" name="password" class="form-control">
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-3">
                                <label for="" class="pull-right">Retype Password</label>
                            </div>
                            <div class="col-md-9">
                                <input type="password" name="re_password" class="form-control">
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-3">

                            </div>
                            <div class="col-md-9">
                                <a href="<?= base_url('admin/admin') ?>" class="btn btn-warning"><i class="fa fa-arrow-left"></i> Kembali</a>
                                <button type="submit" class="btn btn-primary">Edit</button>
                            </div>
                        </div>
                    </div>

                </form>



            </div>
            <!-- /.box-body -->
        </div>
    </div>
</div>