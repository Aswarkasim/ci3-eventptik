<div class="content-wrapper">
    <!-- Main Slider -->

    <?php include('bannerCover.php');
    // require_once('ongoing.php');
    // require_once('eventselesai.php');
    ?>



</div>