<section class="crumina-module crumina-module-slider bg-4 cloud-center navigation-center-both-sides medium-padding100" style="padding: 100px 0">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-lg-offset-3 col-md-12 col-sm-12 col-sm-offset-0">
                <div class="crumina-module crumina-heading align-center">
                    <h6 class="heading-sup-title">Sambutan</h6>
                    <h2 class="h3 heading-title">Ketua Prodi PTIK FT UNM</h2>
                </div>
            </div>
        </div>
        <div class="row"></div>
        <div class="row">
            <div class="col-lg-6 col-lg-offset-3 col-md-6 col-md-offset-3 col-sm-12 col-sm-offset-0">

                <div class="crumina-module crumina-testimonial-item testimonial-item-author-top text-center">

                    <div class="testimonial-img-author">
                        <img src=" <?= base_url('assets/home/') ?>img/author2.png" alt="avatar">
                    </div>

                    <h6 class="testimonial-text">
                        Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est
                        etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum parum claram.
                    </h6>

                    <div class="author-info-wrap">

                        <div class="author-info">
                            <a href="#" class="h6 author-name">Dr. Mustari S. Lamada, M.T.</a>
                            <div class="author-company">Ketua Prodi PTIK</div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--Prev next buttons-->
</section>
<!-- Sambutan -->